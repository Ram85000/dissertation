from flask import Flask, request, render_template, jsonify
import pickle
import pandas as pd

app = Flask(__name__)

with open('gradient_boosting_model.pkl', 'rb') as f:
    model = pickle.load(f)

with open('encoded_columns.pkl', 'rb') as f:
    encoded_columns = pickle.load(f)

def preprocess_input(data):
    input_df = pd.DataFrame([data])

    input_df_encoded = pd.get_dummies(input_df, columns=['sex', 'region', 'discount_eligibility'])

    for col in encoded_columns:
        if col not in input_df_encoded:
            input_df_encoded[col] = 0

    input_df_encoded = input_df_encoded[encoded_columns]

    return input_df_encoded

@app.route('/', methods=['GET', 'POST'])
def home():
    prediction = None
    if request.method == 'POST':
        try:
            user_input = {
                'id': int(request.form['id']),
                'age': int(request.form['age']),
                'bmi': float(request.form['bmi']),
                'children': int(request.form['children']),
                'sex': request.form['sex'],  
                'region': request.form['region'],  
                'discount_eligibility': request.form['discount_eligibility'],  
                'log_premium': float(request.form['log_premium']),
                'bmi_premium_interaction': float(request.form['bmi']) * float(request.form['log_premium']),
                'log_expenses_age_interaction': float(request.form['log_premium']) * int(request.form['age'])
            }

            
            input_data = preprocess_input(user_input)

            
            prediction = model.predict(input_data)[0]  

        except Exception as e:
            prediction = f"Error: {str(e)}"

    return render_template('index.html', prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True)
